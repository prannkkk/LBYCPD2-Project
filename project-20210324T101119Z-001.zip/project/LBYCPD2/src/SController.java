import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class SController {
    public Button UploadButton, CompareButton;
    public Label sIntLabel;

    @FXML
    public void initialize(){
    }

    public void uploadPressed(ActionEvent event){
        Stage stage = (Stage) UploadButton.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choose file");
        fileChooser.showOpenDialog(stage);
    }

    public void comparePressed(ActionEvent event){

    }
}
