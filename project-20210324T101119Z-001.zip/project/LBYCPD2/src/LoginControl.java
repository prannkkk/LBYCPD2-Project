import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class LoginControl {
    private static Scanner x;

    public Label TitleLabel, UsernameLabel, PasswordLabel;
    public TextField UsernameBox, PasswordBox;
    public Button RegButton, LogButton;


    @FXML
    public void loginPressed(ActionEvent event) throws IOException {
        Boolean found = false;
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("StudentsList.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (br != null) {
            String st;
            while ((st = br.readLine()) != null) {
                String[] splitted = st.split(" ");
                if (UsernameBox.getText().equals(splitted[0]) && PasswordBox.getText().equals(splitted[1])) {
                    found = true;
                    ///login as student
                    System.out.println("student log in success");
                    Parent root = FXMLLoader.load(getClass().getResource("sInterface.fxml"));
                    Stage primaryStage = (Stage) PasswordBox.getScene().getWindow();
                    primaryStage.setTitle("Log in account");
                    primaryStage.setScene(new Scene(root, 800, 600));
                    primaryStage.show();
                    break;
                }
                else{
                    try{
                        br = new BufferedReader(new FileReader("FacultyList.txt"));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                    if (br != null) {
                        String st2;
                        while ((st2 = br.readLine()) != null) {
                            String[] splitted2 = st.split(" ");
                            if (UsernameBox.getText().equals(splitted[0]) && PasswordBox.getText().equals(splitted[1])) {
                                found = true;
                                ///login as faculty
                                System.out.println("faculty login success");
                                break;
                            }
                        }
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Log-in Error");
                        alert.setHeaderText(null);
                        alert.setContentText("User not found/Password incorrect.");
                        alert.showAndWait();
                    }
                }
            }
        }
    }
}
