import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

public class SController {
    public Button UploadButton, CompareButton;
    public Label sIntLabel;
    public File selectedFile;
    public ImageView logo;
    private String fileName;

    @FXML
    public void initialize(){
        logo.setImage(new Image("assets/logo.png"));
    }

    public void uploadPressed(ActionEvent event) {
        Stage stage = (Stage) UploadButton.getScene().getWindow();
        FileChooser fileChooser = new FileChooser();                    //for creating the file chooser dialog
        fileChooser.setTitle("Choose file");
        FileChooser.ExtensionFilter filter
                = new FileChooser.ExtensionFilter("Code Files (.java, .cpp, .py)", "*.java", "*.cpp", "*.py");
        fileChooser.getExtensionFilters().add(filter);
        selectedFile = fileChooser.showOpenDialog(stage);               //variable for the chosen file
        fileName = selectedFile.getName();                              //variable for file name that will be used when copying
        File destination = new File("src\\UploadedFiles\\"+fileName);
        try {
            //using Files, the selected file will be copied to specified folder
            Files.copy(selectedFile.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("File uploaded");
            alert.setHeaderText(null);
            alert.setContentText("The file you chose has been uploaded successfully");
            alert.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void comparePressed(ActionEvent event) throws IOException {
        File directoryPath = new File("src/UploadedFiles");
        //List of all files and directories
        String contents[] = directoryPath.list();

        ArrayList<String> savefiles = new ArrayList<String>();
        int fileCount=directoryPath.list().length;
        String[] compFile = new String[fileCount];
        System.out.println("List of files and directories in the specified directory:");
        for(int i=0; i<contents.length; i++) {
            System.out.println("["+ (i+1) +"]" + contents[i]);
        }

        for(File file : directoryPath.listFiles()){
            savefiles.add(file.getName());
        }

        if(fileCount == 0){
            contents = null;
        }

        System.out.println("Number of files: " + fileCount);
        /*for(int j = 0; j<fileCount; j++)
        {
            String var[j] = directoryPath.list();

        }*/

        for (int i = 0; i < fileCount; i++){
            String s = savefiles.get(i);
            String x = "src/UploadedFiles/"+s;
            System.out.println("File "+i+" : "+s);
            compFile[i] = Files.readString(Paths.get(x));
        }

        System.out.print("\n");
        System.out.print("\n");
        System.out.print("\n");
        System.out.print("Programs: \n");

        if(contents == null){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error!");
            alert.setHeaderText(null);
            alert.setContentText("Package folder is empty, please add files first.");
            alert.showAndWait();
        } else{
            SimilarityChecker similarityChecker = new SimilarityChecker();
            similarityChecker.similarityMatrix(compFile);;
        }
    }

}
