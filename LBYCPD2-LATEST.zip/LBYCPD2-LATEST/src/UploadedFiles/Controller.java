import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;

public class Controller {

    public TextField nameField;
    public Label statusLabel, userName, userStatus, userQuote;
    public TextField statusChangeLabel;
    public TextField pictureLabel;
    public TextField friendLabel;
    public TextField unfriendLabel;
    public TextField quoteLabel;
    public ImageView pictureView;
    public ListView listView;
    public VBox background;

    ObservableList<String> friendList;
    HashMap<String, LinkedList<String>> friendsMap = new HashMap<>();
    HashMap<String, LinkedList<String>> infoMap = new HashMap<>();

    void addConnections(String src, String dest){                          //function for adding the edge

        if(!friendsMap.keySet().contains(src)){                    //if adjlist does not have src, add src in the keys
            friendsMap.put(src, null);
        }
        if(!friendsMap.keySet().contains(dest)){                   //if adjlist does not have dest, add dest in the keys
            friendsMap.put(dest, null);
        }
        LinkedList<String> temp = friendsMap.get(src);          //get contents of src, if contents are null; add dest
        if (temp == null){
            temp = new LinkedList<>();
        }
        temp.add(dest);                                         //add temp (dest) to src then add both to hashmap
        friendsMap.put(src, temp);
        LinkedList<String> temp2 = friendsMap.get(dest);        //gets contents of dest, if contents are null; add src
        if (temp2 == null){
            temp2= new LinkedList<>();
        }
        if (!temp2.contains(src)){                              //add temp2 (src) to dest then add both to hashmap
            temp2.add(src);
            friendsMap.put(dest, temp2);
        }
    }

    void displayConnections(String key){
        for(String nameFriend: friendsMap.get(key)){            //for loop for displaying the values of key (userName)
            listView.getItems().add(nameFriend);                //add the values to the listView
            System.out.println(nameFriend);
        }
    }

    void deleteConnections(String key, String value){           //removes specific value from the key
        friendsMap.get(key).remove(value);
        friendsMap.get(value).remove(key);                      //removes specific key from value if it exists
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @FXML
    private  void initialize(){
        userName.setText("Gil Garcia");                                     //initialize user and info
        addConnections("Gil Garcia", "Neil Lacson");       //add preset friends for user
        addConnections("Gil Garcia", "Neal Ayque");
        addConnections("Ned Huet", "Gil Garcia");
        addConnections("Ned Huet", "Neil Lacson");
        addConnections("Brian Jodi", "Gil Garcia");
        displayConnections(userName.getText());                             //call method to display friends
        userStatus.setText("Single and ready to mingle");
        userQuote.setText("I don't use Java because I sting like a python");
        Image image = new Image(getClass().getResource("Gil Garcia.jpg").toExternalForm());
        pictureView.setImage(image);                                        //initialize image
    }

    public void handleAdd(ActionEvent actionEvent) {
        if (!nameField.getText().trim().isEmpty()) {
            addConnections(userName.getText(), nameField.getText());        //calls addConnections to add friend
            listView.getItems().clear();                                    //resets the contents of listView
            displayConnections(userName.getText());                         //calls displayConnections to display friends
            statusLabel.setText(nameField.getText() + " added");            //edits the statusLabel below to display action
        }
    }

    public void handleDelete(ActionEvent actionEvent) {
        if (!nameField.getText().trim().isEmpty()) {
            deleteConnections(userName.getText(), nameField.getText());     //calls method for friend deletion
            listView.getItems().clear();                                    //resets the contents of listView
            displayConnections(userName.getText());                         //calls displayConnections to display friends
            statusLabel.setText(nameField.getText() + " deleted");
        }
    }

    public void handleLookup(ActionEvent actionEvent) {
        if (!nameField.getText().trim().isEmpty()) {
            listView.getItems().clear();                                    //resets friends list
            displayConnections(nameField.getText());                        //displays new friends list
            userName.setText(nameField.getText());                          //changes the current userName
            Image image = new Image(getClass().getResource(nameField.getText()+".jpg").toExternalForm());
            pictureView.setImage(image);                                    //changes user's current image
            userStatus.setText("Please set custom status");
            quoteLabel.setText("Please set custom quote");
            statusLabel.setText(nameField.getText() + " lookup");
        }
    }

    public void handleStatus(ActionEvent actionEvent) {
        if (!statusChangeLabel.getText().trim().isEmpty()) {                ///method for changing the custom status
            statusLabel.setText("status changed to " + statusChangeLabel.getText());
        }
    }

    public void handlePicture(ActionEvent actionEvent) {
        if (!pictureLabel.getText().trim().isEmpty()) {
            Image image = new Image(getClass().getResource(pictureLabel.getText()+".jpg").toExternalForm());
            pictureView.setImage(image);                                    //used for changing the image on the profile
            statusLabel.setText("picture changed to " + pictureLabel.getText());
        }
    }

    public void handleAddFriend(ActionEvent actionEvent) {
        if (!friendLabel.getText().trim().isEmpty()) {                      //adds searched profile to my own profile
            addConnections("Gil Garcia", friendLabel.getText());
            listView.getItems().clear();
            displayConnections(userName.getText());
            statusLabel.setText(friendLabel.getText() + " added as friend");
        }
    }

    public void handleUnfriend(ActionEvent actionEvent) {                   //deletes searched profile to own profile
        if (!unfriendLabel.getText().trim().isEmpty()) {
            deleteConnections("Gil Garcia", unfriendLabel.getText());
            listView.getItems().clear();
            displayConnections(userName.getText());                         //displays new list of friends
            friendList.remove(unfriendLabel.getText());
            statusLabel.setText(unfriendLabel.getText() + " removed as friend");
        }
    }

    public void handleQuote(ActionEvent actionEvent) {
        if (!quoteLabel.getText().trim().isEmpty()) {
            statusLabel.setText("Quote changed to " + quoteLabel.getText());
        }
    }
}
