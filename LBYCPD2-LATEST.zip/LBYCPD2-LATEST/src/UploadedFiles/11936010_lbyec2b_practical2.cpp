#include <iostream>
#include <conio.h>

#define healAmount 15
#define buffAtkAmount 10
#define buffDefAmount 5

using namespace std;

class Character{
	private:
		int vit;
		int atk;
		int def;
	public:
		//Constructor
		Character(int a, int b, int c){
			vit = a;
			atk = b;
			def = c;
		}
		
		//Setter
		void setVit(int x){
			vit = x;
		}
		void setAtk(int x){
			atk = x;
		}
		void setDef(int x){
			def = x;
		}
		
		//Getter
		int getVit(){
			return vit;
		}	
		int getAtk(){
			return atk;
		}	
		int getDef(){
			return def;
		}
			
		void showStats(){
			cout << "\tVitality Rating: " << vit << "\n";
			cout << "\tAttack Rating: " << atk << "\n";
			cout << "\tDefense Rating: " << def << "\n";
		}
};


class Player: public Character{
	public:
		//Constructor
		Player(int a, int b, int c):Character(a,b,c){
		}
		
		void healUp(int x){
			//-----------------------------------------------------------------------------------------------
			// -> increase the vitality of the hero by x
			//INSERT CODE HERE - START
			setVit(getVit()+x);
			//INSERT CODE HERE - END
			//-----------------------------------------------------------------------------------------------
		}
		
		void buffWeapon(int x){
			//-----------------------------------------------------------------------------------------------
			// -> increase the attack of the hero by x
			//INSERT CODE HERE - START
			setAtk(getAtk()+x);
			//INSERT CODE HERE - END
			//-----------------------------------------------------------------------------------------------
		}
		
		void buffArmor(int x){
			//-----------------------------------------------------------------------------------------------
			// -> increase the defense of the hero by x
			//INSERT CODE HERE - START
			setDef(getDef()+x);
			//INSERT CODE HERE - END
			//-----------------------------------------------------------------------------------------------
		}
};

int main(){
	Player hero(30, 5, 0); //30 starting hp, 5 starting atk, 0 starting def
	Character monster(30, 10, 10); //30 starting hp, 10 starting atk, 10 starting def
	
	int i, action, dmg;
			
	cout << "Welcome to the LBYEC2B Practical Exam 2 Adventure Game" << "\n";
	
	while(hero.getVit() > 0 || monster.getVit() > 0){
		cout << "Hero Stats:\n";
		hero.showStats();
		cout << "\nMonster Stats:\n";
		monster.showStats();
		cout << "\nAvailable actions:\n";
		cout << "\t (1) Attack Monster\n" << "\t (2) Heal Up\n" << "\t (3) Buff Weapon\n" << "\t (4) Buff Armor\n";
		cout << "Choose Action: ";
		cin >> action;
	
		switch(action){
			case 1:
				//-------------------------------------------------------------------------------------------
				// -> reduces the vitality of the monster by 'dmg'
				// -> 'dmg' is calculated by subtracting the monster's defense from the hero's attack
				// -> if the negative computed 'dmg' is negative, it should be set to zero
				//INSERT CODE HERE - START
				dmg = hero.getAtk() - monster.getDef();
				if(dmg<0){
					dmg = 0;
				}
				monster.setVit(monster.getVit()-dmg);
				//INSERT CODE HERE - END
				//-------------------------------------------------------------------------------------------
				cout << "The hero deals " << dmg << " damage to the monster!\n";
				break;	
			case 2:
				//-------------------------------------------------------------------------------------------
				// -> calls the correct method and increases the vitality of the hero by 'healAmount'
				//INSERT CODE HERE - START
				hero.healUp(healAmount);
				//INSERT CODE HERE - END
				//-------------------------------------------------------------------------------------------
				cout << "The hero heals " << healAmount << " hp!\n";
				break;	
			case 3:
				//-------------------------------------------------------------------------------------------
				// -> calls the correct method and increases the attack of the hero by 'buffAtkAmount'
				//INSERT CODE HERE - START
				hero.buffWeapon(buffAtkAmount);
				//INSERT CODE HERE - END
				//-------------------------------------------------------------------------------------------
				cout << "The hero's attack increased by " << buffAtkAmount << " points!\n";
				break;	
			case 4:
				//-------------------------------------------------------------------------------------------
				// -> calls the correct method and increases the defense of the hero by 'buffDefAmount'
				//INSERT CODE HERE - START
				hero.buffArmor(buffDefAmount);
				//INSERT CODE HERE - END
				//-------------------------------------------------------------------------------------------
				cout << "The hero's defense increased by " << buffDefAmount << " points!\n";
				break;	
			default:
				cout << "The hero skips his turn!" << "\n";
				break;
		}
		//---------------------------------------------------------------------------------------------------
		// -> reduces the vitality of the hero by 'dmg'
		// -> 'dmg' is calculated by subtracting the hero's defense from the monster's attack
		// -> if the negative computed 'dmg' is negative, it should be set to zero
		//INSERT CODE HERE - START
		dmg = monster.getAtk() - hero.getDef();
        if(dmg < 0){
            dmg = 0;
        }
        hero.setVit(hero.getVit() - dmg);
		//INSERT CODE HERE - END
		//---------------------------------------------------------------------------------------------------
		cout << "The monster deals " << dmg << " damage to the hero!\n";
		
		if(monster.getVit() <= 0){
			monster.setVit(0);
		}
		if(hero.getVit() <= 0){
			hero.setVit(0);
		}
		if((monster.getVit()==0) && (hero.getVit() == 0)){
			cout << "\nThe battle ended in a DRAW!";
			return 0;
		}                  
		else if(monster.getVit()==0){
			cout << "\nThe hero WINS the battle!";
			return 0;
		}
		else if(hero.getVit() == 0){
			cout << "\nThe hero LOSES the battle!";
			return 0;
		}
		
		cout << "\nPress any key to continue...";
		getch();
		system("cls");
	}
}
