import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.*;

public class RController {
    public Button confirmRegister;
    public TextField inputUsername;
    public PasswordField inputPassword, inputConfirm;
    public ImageView RegisterImage;

    @FXML
    public void initialize(){
        Image image = new Image("assets/logo.png");
        RegisterImage.setImage(image);
    }

    @FXML
    public void confirmPressed(ActionEvent event) throws IOException {
        BufferedReader br = null;
        if (!inputPassword.getText().equals(inputConfirm.getText())) {
            //checker if password is not the same as the input in confirm password
            //shows dialog if error
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Register Error");
            alert.setHeaderText(null);
            alert.setContentText("Password does not match, please retry again.");
            alert.showAndWait();
        } else {
            try {
                //reads students list for checking if account is already existing
                br = new BufferedReader(new FileReader("StudentsList.txt"));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            if (br != null) {
                String st;
                while ((st = br.readLine()) != null) {
                    String[] splitted = st.split(" ");
                    //array for the split account informations (username, password)
                    if (inputUsername.getText().equals(splitted[0])) {
                        //if username is already existing, show dialog error
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Register Error");
                        alert.setHeaderText(null);
                        alert.setContentText("Account already existing.");
                        alert.showAndWait();
                        break;
                    } else {
                        //else add the account information on StudentsList.txt
                        addAccount();
                        //show dialog that account successfully created
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Register successful");
                        alert.setHeaderText(null);
                        alert.setContentText("Account sucessfully registered");
                        alert.showAndWait();
                        //load the login screen after registering
                        Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
                        Stage primaryStage = (Stage) inputUsername.getScene().getWindow();
                        primaryStage.setTitle("Log in account");
                        primaryStage.setScene(new Scene(root, 450, 250));
                        primaryStage.show();
                    }
                    break;
                }
            }
        }
    }

    private void addAccount() {
        //adds the account information through combining the two input strings
        String accountInfo = inputUsername.getText() + " " + inputPassword.getText();
        try {
            //uses PrintWriter to append the combined string into the StudentsList.txt file
            PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("StudentsList.txt", true)));
            out.println(accountInfo);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
