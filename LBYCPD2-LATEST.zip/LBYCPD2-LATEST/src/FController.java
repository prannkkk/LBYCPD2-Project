import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class FController {
    public Button viewFiles, deleteButton;
    public Button compFile;
    public Label fLabel;
    public ListView<String> filesTable;
    public ObservableList names = FXCollections.observableArrayList();
    public String filenameDelete;
    public File deleteFile;
    public ImageView logo;



    File directoryPath = new File("src/UploadedFiles");
    //List of all files and directories

    public TextArea console;
    public static PrintStream ps;



    @FXML
    public void initialize(){
        logo.setImage(new Image("assets/logo.png"));
        ps=new PrintStream(new Console(console));
    }

    public class Console extends OutputStream{
        private TextArea console;

        public Console(TextArea console){
            this.console = console;
        }
        public void appendText(String valueOf){
            Platform.runLater(()->console.appendText(valueOf));
        }
        public void write(int b) throws IOException{
            appendText(String.valueOf((char)b));
        }
    }

    public void viewPressed(ActionEvent event)
    {
        String contents[] = directoryPath.list();
        filesTable.getItems().clear();
        names.clear();
        names.addAll(contents);
        filesTable.setItems(names);
    }

    public void deleteSelected(ActionEvent event){
        int ind = filesTable.getSelectionModel().getSelectedIndex();
        if(ind>=0){
            filenameDelete = filesTable.getSelectionModel().getSelectedItem();
            deleteFile = new File("src/UploadedFiles/"+filenameDelete);
            deleteFile.delete();
            filesTable.getItems().remove(ind);
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Chosen file deleted");
        alert.setHeaderText(null);
        alert.setContentText("Your chosen file: "+filenameDelete+" is deleted from the folder.");
        alert.showAndWait();
    }

    public void compareAll(ActionEvent event) throws IOException {
        System.setOut(ps);
        System.setErr(ps);
        ArrayList<String> savefiles = new ArrayList<String>();
        int fileCount=directoryPath.list().length;
        String[] compFiles = new String[fileCount];
        for(File file : directoryPath.listFiles()){
            savefiles.add(file.getName());
        }
        System.out.println("\n");
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        System.out.println(formatter.format(date));
        for (int i = 0; i < fileCount; i++){
            String s = savefiles.get(i);
            String x = "src/UploadedFiles/"+s;
            System.out.println("File "+i+1+" : "+s);
            compFiles[i] = Files.readString(Paths.get(x));
        }

        System.out.print("\n");
        System.out.print("Programs: \n");

        Stage stage = (Stage) viewFiles.getScene().getWindow();

        similarityMatrix(compFiles);
    }

    static void similarityMatrix(String [] programs)
    {

        int x;
        int y;
        int z;


        System.out.println("===============================================================================================");
        System.out.printf("%-13s", "");

        for (x = 0; x < programs.length; x++)
        {
            System.out.printf("%-1s%d%s"    , "|File ", x + 1, "|");
        }

        for (y = 0; y < programs.length; y++)
        {
            if (y  < 9 )
            {
                System.out.printf("\n%s%d%-5s", "File ", y + 1, "  |");
            }
            else
            {
                System.out.printf("\n%s%d%-4s", "File ", y + 1, " |");
            }

            for (z = 0; z < programs.length; z++)
            {
                System.out.printf("%-13.2f", naiveSimilarity(programs[y], programs[z]));
            }

        }

        System.out.print("\n");
        System.out.println("===============================================================================================");
    }

    static float naiveSimilarity(String progX, String progY)
    {
        String[] words1 = progX.split(" +");
        //printTokens(words1)

        String[] words2 = progY.split(" +");
        //printTokens(words2);

        int minLength = Math.min(words1.length, words2.length);
        int count = 0;
        for (int x = 0; x < minLength; x++)
        {
            if (words1[x].equals(words2[x]))
            {
                count++;
            }
        }
        return (100 * (float) count/minLength);
    }
}

