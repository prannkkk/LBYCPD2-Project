import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.Scanner;

public class LoginControl {
    private static Scanner x;
    public Label TitleLabel, UsernameLabel, PasswordLabel;
    public TextField UsernameBox, PasswordBox;
    public Button RegButton, LogButton;
    public ImageView LoginImage;

    @FXML
    public void initialize(){
        Image image = new Image("assets/logo.png");
        LoginImage.setImage(image);
    }

    @FXML
    public void loginPressed(ActionEvent event) throws IOException {
        Boolean found = false;
        BufferedReader br = null;
        try {
            //reader for checking studentlist.txt
            br = new BufferedReader(new FileReader("StudentsList.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (br != null) {
            String st;
            //loop for checking each line
            while ((st = br.readLine()) != null) {
                //basis for splitting the line into two parts
                String[] splitted = st.split(" ");
                if (UsernameBox.getText().equals(splitted[0]) && PasswordBox.getText().equals(splitted[1])) {
                    found = true;
                    ///if correct, login as student
                    System.out.println("student log in success");
                    Parent root = FXMLLoader.load(getClass().getResource("sInterface.fxml"));
                    Stage primaryStage = (Stage) PasswordBox.getScene().getWindow();
                    primaryStage.getIcons().add(new Image("assets/logo.png"));
                    primaryStage.setTitle("Student interface");
                    primaryStage.setScene(new Scene(root, 684, 400));
                    primaryStage.show();
                    break;
                }
            }
            if(found==false){
                facultyCheck();
            }
        }
    }
    public void facultyCheck() throws IOException {
        Boolean found = false;
        BufferedReader br2 = null;
        //if not found in student, check facultylist.txt
        try {
            //new reader for checking facultylist.txt
            br2 = new BufferedReader(new FileReader("FacultyList.txt"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        if (br2 != null) {
            String st2;
            //loop for checking each line
            while ((st2 = br2.readLine()) != null) {
                //basis for splitting the line into two parts
                String[] splitted2 = st2.split(" ");
                if (UsernameBox.getText().equals(splitted2[0]) && PasswordBox.getText().equals(splitted2[1])) {
                    found = true;
                    ///if correct, login as faculty
                    System.out.println("faculty login success");
                    Parent root = FXMLLoader.load(getClass().getResource("fInterface.fxml"));
                    Stage primaryStage = (Stage) PasswordBox.getScene().getWindow();
                    primaryStage.getIcons().add(new Image("assets/logo.png"));
                    primaryStage.setTitle("Faculty interface");
                    primaryStage.setScene(new Scene(root, 700, 600));
                    primaryStage.show();
                    break;
                } else {
                    displayError();
                }
            }
        }
    }

    public void displayError()
    {
        //if not found in both, error dialog is displayed
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Log-in Error");
        alert.setHeaderText(null);
        alert.setContentText("User not found/Password incorrect.");
        alert.showAndWait();
    }


    public void registerPressed(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("register.fxml"));
        Stage primaryStage = (Stage) PasswordBox.getScene().getWindow();
        primaryStage.getIcons().add(new Image("assets/logo.png"));
        primaryStage.setTitle("Log in account");
        primaryStage.setScene(new Scene(root, 450, 300));
        primaryStage.show();
    }

}
