import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SimilarityChecker {

    public static void run() throws IOException {
        File directoryPath = new File("src/UploadedFiles");
        //List of all files and directories
        String contents[] = directoryPath.list();
        ArrayList<String> savefiles = new ArrayList<String>();
        int fileCount=directoryPath.list().length;
        String[] compFile = new String[fileCount];
        System.out.println("List of files and directories in the specified directory:");
        for(int i=0; i<contents.length; i++) {
            System.out.println("["+ (i+1) +"]" + contents[i]);
        }

        for(File file : directoryPath.listFiles()){
            savefiles.add(file.getName());
        }

        System.out.println("Number of files: " + fileCount);
        /*for(int j = 0; j<fileCount; j++)
        {
            String var[j] = directoryPath.list();

        }*/

        for (int i = 0; i < fileCount; i++){
            String s = savefiles.get(i);
            String x = "src/UploadedFiles/"+s;
            System.out.println("File "+i+" : "+s);
            compFile[i] = Files.readString(Paths.get(x));
        }

        System.out.print("\n");
        System.out.print("\n");
        System.out.print("\n");
        System.out.print("Programs: \n");
        similarityMatrix(compFile);
    }
    static void similarityMatrix(String [] programs)
    {

        int x;
        int y;
        int z;

        System.out.println("===============================================================================================");
        System.out.printf("%-13s", "");

        for (x = 0; x < programs.length; x++)
        {
            System.out.printf("%-1s%d%s"    , "|File ", x + 1, "|");
        }

        for (y = 0; y < programs.length; y++)
        {
            if (y  < 9 )
            {
                System.out.printf("\n%s%d%-5s", "File ", y + 1, "  |");
            }
            else
            {
                System.out.printf("\n%s%d%-4s", "File ", y + 1, " |");
            }

            for (z = 0; z < programs.length; z++)
            {
                System.out.printf("%-13.2f", naiveSimilarity(programs[y], programs[z]));
            }

        }

        System.out.print("\n");
        System.out.println("===============================================================================================");
    }

    static float naiveSimilarity(String progX, String progY)
    {
        String[] words1 = progX.split(" +");
        //printTokens(words1)

        String[] words2 = progY.split(" +");
        //printTokens(words2);

        int minLength = Math.min(words1.length, words2.length);
        int count = 0;
        for (int x = 0; x < minLength; x++)
        {
            if (words1[x].equals(words2[x]))
            {
                count++;
            }
        }
        return (100 * (float) count/minLength);
    }
}
